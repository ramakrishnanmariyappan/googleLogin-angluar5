
## Configuration Change
This project used Google Authendication Login functionality, below settings need to change

Adminstrator Account
--------------------------
Change the environment file in the environment folder

----> Change the admin gmail address 

After that email address act as a administrator mail.

User Account
--------------------------
If you enter different email address act as a user account  

## Development server

Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

## Build

Run `ng build` to build the project. The build artifacts will be stored in the `dist/` directory. Use the `-prod` flag for a production build.

## Local server connection
open server folder and enter below command in command prompt
-------------------------------
node server.js

## Code Coverage

ng test --code-coverage.






